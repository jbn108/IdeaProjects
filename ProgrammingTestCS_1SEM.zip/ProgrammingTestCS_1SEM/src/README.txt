Individual programming test 
1st Semester Computer Science, AP Degree 
 
Test time: 3 hours, 9:00->12:00
Allowed help: Internet, books, etc. Only human help prohibited, no 
communication during test.

The project holds a JUnit test, what you can use to get immediate
feedback, if you pass the different test. You may not alter the tests. 
This test holds is a number of sub-assignments. Each sub assignment has 
a number of tests associated with them. 

Test each assignment by right clicking the class to test, and 
choose "Test".

You can run all tests by right clicking the project and choose 
"Test" (ctrl+shift+f10).

Individual assessment will be done by a teacher.

*** You need a "Tests passed" of at least 50% to pass ***

It is not allowed to change the tests.
It will also not affect the grading done by the teacher, as they are using a different test set.

You have to upload your finished assignent on Moodle. Zip the project
folder and upload the zip file.

If you cannot pass the test, you will have an individual talk with
a teacher to help you to progress to a point where you are able to
pass the test. E.g. online training and/or tutoring.

